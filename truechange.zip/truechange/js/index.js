$('.owl-carousel').owlCarousel({
  loop: false,
  margin: 50,
  nav: true,
  dots: true,
  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 1,
      nav: false
    },
    992: {
      items: 2
    },
    1200: {
      items: 3
    }
  }
})

$("#menuToggle").click(function(){
    if ($(".nav-mobile").hasClass("expanded")) {
    $(".nav-mobile.expanded").removeClass("expanded");
    $(this).removeClass("active");
    } else {
    $(".nav-mobile").addClass("expanded");
    $(this).addClass("active");
    }
});

$('a[href^="#"]').on('click', function(e) {
    e.preventDefault();
    var id = $(this).attr('href'),
        targetOffset = $(id).offset().top;
        
    $('html, body').animate({ 
      scrollTop: targetOffset - 0
    }, 500);
});

function validateEmail(email) {
    const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
  
function validate() {
    const $result = $("#result");
    const email = $("#email").val();
    $result.text("");
  
    if (validateEmail(email)) {
      $result.text(" Registration successful ");
      $result.css("color", "green");
    } else {
      $result.text(" Email not valid ");
      $result.css("color", "red");
    }
    return false;
}
  
$("#validate").on("click", validate);